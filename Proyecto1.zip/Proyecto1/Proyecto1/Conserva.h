#pragma once
#include "Producto.h"

class Conserva : public Producto {

public:
    
    Conserva(string cod, string nom_comerc, string descr, double precio, string categ, int existe, int limit, Fecha* fech, bool envasado);
   
    // M�todos getters y setters
    bool getEnvasado();
    void setEnvasado(bool envasado);

    string toString() const override;

private:
    bool envasado;
};